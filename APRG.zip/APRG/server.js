const express = require('express');
const app = express()
app.use(express.static(__dirname + '/stylings'));

const bodyParser= require('body-parser')
app.use(bodyParser.urlencoded({extended: true}))

app.engine('.ejs', require('ejs').__express);
app.set('view engine', 'ejs');

const sqlite3 = require('sqlite3').verbose();
let database = new sqlite3.Database('data.db');


const session = require('express-session');
app.use(session({
    secret: 'example',
    resave: false,
    saveUninitialized: true
}));


const bcrypt = require('bcrypt');
const saltRounds = 8;

app.listen(3001, () => {
    console.log("Server is listening on 3001");

    database.each(`SELECT * FROM users`, (error, row) => {
        console.log(row);
    });
    database.each(`SELECT * FROM objekte`, (error, row) => {
        console.log(row);
    });
    database.each(`SELECT * FROM bewerbungen`, (error, row) => {
        console.log(row);
    });
});

app.get('/', (request, response) => {
    let authenticated = request.session.authenticated;
    let mail = request.session.mail;

    let greeting;
    const sql1 = "SELECT bild1, ort, id FROM objekte"; 
    if (!authenticated) {
        greeting = "Moin!";
    }
    else {
        greeting = `Moin, ${mail}!`;
    }

    database.all(sql1, function(err, rows){
        if (err){
            console.log(err.message);
        }
        else {
            response.render('index', {
                isLoggedIn: authenticated,
                greeting: greeting,
                rows:rows

            });
        }
    });
});
    
app.get('/dsgvo', (request, response) => {
    response.render('dsgvo');
});
app.get('/impressum', (request, response) => {
    response.render('impressum');
});

app.get('/object', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungA1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});

app.get('/object1', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungB1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});
app.get('/object2', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungC1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});

app.get('/object3', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungD1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});
app.get('/object4', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungE1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});
app.get('/object5', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungF1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});
app.get('/object6', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungG1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});
app.get('/object7', (request, response) => {
    if (request.session.authenticated) {
        database.get(`SELECT * FROM objekte WHERE bild1='wohnungH1.png'`, function(error,row) {
            if (error) {
                console.log(error);
                response.redirect('/login');
                return;
            }
            else{
                ort = row.ort;
                preis = row.preis;
                grosse = row.grosse;
                beschreibung = row.beschreibung;
                bild1 = row.bild1;
                bild2 = row.bild2;
                bild3 = row.bild3;
                wohnid = row.id;
                response.render('object', {
                    ort:ort,
                    preis:preis,
                    grosse:grosse,
                    beschreibung:beschreibung,
                    bild1:bild1,
                    bild2:bild2,
                    bild3:bild3,
                    wohnid:wohnid
                });
            }
        
    
        });
}
else {
    response.redirect('/login');
}
});







app.get('/login', (request, response) => {
    if (!request.session.authenticated) {
        response.render('login', {
            error: false
        });
    }
    else {
        response.redirect('/');
    }
});
app.post('/login', (request, response) => {
    let mail = request.body.mail;
    let password = request.body.password;

    database.get(`SELECT * FROM users WHERE mail='${mail}'`, function(error, row) {
        if (error) {
            console.log(error);
            response.redirect('/login');
            return;
        }

        if (row != null) {
            bcrypt.compare(password, row.password, (error, result) => {
                if (error) {
                    console.log(error);
                    response.redirect('/login');
                    return;
                }

                if (result == true) {
                    request.session.authenticated = true;
                    request.session.mail = row.mail;
                    response.redirect('/');
                }
                else {
                    response.render('login', {
                        error: true
                    });
                }
            });
        } 
        else {
            response.render('login', {
                error: true
            });
        }
    });
});

app.post('/logout', (request, response) => {
    request.session.destroy();
    response.redirect('/');
});
app.get('/register', (request, response) => {
    if (!request.session.authenticated) {
        response.render('register', {
            error: null
        });
    }
    else {
        response.redirect('/');
    }
});
app.post('/bewerben', (request, response) => {
    let mail = request.session.mail;
    let wohnid = request.body.id;

    database.get(`SELECT id FROM users WHERE mail='${mail}'`, function(error, row) {
        if (error) {
            console.log(error);
            response.redirect('/register');
            return;
        }
        else{
            let userid = row.id;
        
            database.run(`INSERT INTO bewerbungen (userID, objektID) VALUES ('${userid}', '${wohnid}')`, (error) => {
                if (error) {
                    console.log(error);
                     response.redirect('/register');
                    return;
                }
                else{
                    console.log(`Mission accomplished`);
                    response.redirect('/');
                }
            });
        }
    });
});
app.post('/register', (request, response) => {
    let mail = request.body.mail;
    let password = request.body.password;
    let passwordConfirm = request.body.passwordConfirm;
    let name = request.body.name;
    let gehalt = request.body.gehalt;
    let beruf = request.body.beruf

    if (password != passwordConfirm) {
        response.render('register', {
            error: "Passwörter müssen übereinstimmen!"
        });
        return;
    }

    database.get(`SELECT * FROM users WHERE mail='${mail}'`, function(error, row) {
        if (error) {
            console.log(error);
            response.redirect('/register');
            return;
        }

        if (row == null) {
            bcrypt.hash(password, saltRounds, (error, hash) => {
                if (error) {
                    console.log(error);
                    response.redirect('/register');
                    return;
                }

                database.run(`INSERT INTO users (mail, password, name, gehalt, beruf) VALUES ('${mail}', '${hash}', '${name}', '${gehalt}', '${beruf}')`, (error) => {
                    if (error) {
                        console.log(error);
                        response.redirect('/register');
                        return;
                    }
                });
                console.log(`Acoount '${mail} registered`);
                request.session.authenticated = true;
                request.session.mail = mail;
                response.redirect('/');
            });
        }
        else {
            response.render('register', {
                error: "Benutzername bereits vorhanden."
            });
        }
    });
}); 


app.post('/login', (request, response) => {
    let mail = request.body.mail;
    let password = request.body.password;

    database.get(`SELECT * FROM users WHERE mail='${mail}'`, function(error, row) {
        if (error) {
            console.log(error);
            response.redirect('/login');
            return;
        }

        if (row != null) {
            bcrypt.compare(password, row.password, (error, result) => {
                if (error) {
                    console.log(error);
                    response.redirect('/login');
                    return;
                }

                if (result == true) {
                    request.session.authenticated = true;
                    request.session.mail = row.mail;
                    response.redirect('/');
                }
                else {
                    response.render('login', {
                        error: true
                    });
                }
            });
        } 
        else {
            response.render('login', {
                error: true
            });
        }
    });
});

app.get("/admin", function(req, res){
    let authenticated = req.session.authenticated;
    let mail = req.session.mail;
	const sql = "SELECT mail, name, gehalt, beruf, bild1 FROM users, objekte, bewerbungen WHERE users.id = bewerbungen.userID AND bewerbungen.objektID = objekte.id";
    
    
    if (!authenticated) {
        res.redirect('login');
    }

    if (mail != "admin@admin.de") {
        res.redirect('login');
    }
    else {   
        database.all(sql, function(err, rows){
            if (err){
                console.log(err.message);
            }
            else {
                res.render("admin", {rows: rows});
            }
        });
    }   
});

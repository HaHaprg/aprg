DROP TABLE users;
DROP TABLE objekte;
DROP TABLE bewerbungen;

CREATE TABLE users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    password TEXT NOT NULL,
    mail TEXT NOT NULL,
    name TEXT NOT NULL,
    gehalt NUMERIC,
    beruf TEXT
);


SELECT * FROM users;

CREATE TABLE objekte(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ort TEXT NOT NULL,
    preis NUMERIC NOT NULL,
    grosse NUMERIC NOT NULL,
    beschreibung TEXT,
    bild1 TEXT NOT NULL,
    bild2 TEXT,
    bild3 TEXT
);

INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Altona", 764, 12, "Der Kauf einer Eigentumswohnung im Neubauprojekt P84a lässt Sie heimkommen, ankommen und genießen. Dafür sorgen weite, lichte Räume, bodentiefe Fenster und ausgewählte, hochwertige Materialien. Wer hier lebt, hat seinen persönlichen Ort der Ruhe und inneren Balance gefunden. Pragmatisch und doch feinsinnig, wohnlich und dabei geborgen - die kubische Architektur des Gebäudes bildet einen gelungenen Kontrast zu der umgebenden, stilvollen Gartenanlage.

Nutzen Sie den Fahrstuhl und erreichen Sie Ihre Wohnung bequem aus der Tiefgarage. Entspannen Sie auf dem großzügigen Balkon. Das Parkett mit Fußbodenheizung und die exklusive Sanitärausstattung von Markenherstellern machen Ihr neues Wohnglück perfekt.", "wohnungA1.png", "wohnungA2.png", "wohnungA3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Horn", 587, 30, "Das Leben im Neubau GARDIA gestaltet sich ganz natürlich. Warm leuchtet das hochwertige Eichenparkett im Sonnenlicht und schafft eine leichte und entspannte Atmosphäre. Die in der gesamten Wohnung verlegte Fußbodenheizung schafft zudem eine angenehme Gelassenheit, die durch moderne Technik, wie der Video-Gegensprechanlage, ergänzt wird. 

Sie sind die Juwelen des Alltags, die besonderen Momente, in denen wir mal nur an uns denken können und uns mit kleinen aber feinen Ritualen verwöhnen. Sei es beim gemütlichen Kochen im offenen Wohn-Essbereich oder beim Entspannen in der Wellness-Oase Badezimmer. Großformatige Fliesen und stilvolle Sanitärobjekte in den Bädern bestechen durch ihre Eleganz. 
", "wohnungB1.png", "wohnungB2.png", "wohnungB3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Blankenese", 1759, 35, "Zum 01.09.2019 können Sie diese Terrassenwohnung im Erdgeschoss, die durch eine gehobene Innenausstattung besticht, erwerben. Bei dieser ansprechenden Immobilie handelt es sich um einen Erstbezug. Fotos von der Wohnung folgen nach Baufortschritt im Innenausbau.

Nach Ihren Wünschen gestalten Sie die Küche im 40qm großen Wohn/Esszimmer oder auch in dem nebenan gelegenen Zimmer. Die Böden, ob Parkett, Design-Vinyl oder Teppichboden im Wohn/Esszimmer und den drei Schlafzimmern, suchen Sie selbst aus und lassen sie selbst verlegen.

Die Decken werden fertig verspachtelt und weiß gestrichen übergeben. Die Wände sind verputzt, der Eigentümer kann diese nach eigenem Geschmack streichen oder tapezieren lassen.

Das Tageslicht-Badezimmer besticht mit einer Badewanne und einer extra langen und offenen Duschnische mit Duschtasse. Auch hier wurden, wie in der gesamten Wohnung, nur hochwertige Materialien verbaut (Duravit Stonetto, Größe 140 x 90 cm). Auch das zweite Bad ist mit Dusche und WC voll ausgestattet und erhöht den Nutzwert dieser Immobilie nachhaltig.", "wohnungC1.png", "wohnungC2.png", "wohnungC3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Hamm", 1444, 40, "In einer ruhigen Seitenstraße im Bockhorst 179 entsteht ein Mehrfamilienhaus mit 11 Wohneinheiten. Die Penthouse-Wohnung Nr. 10 befindet sich im 3. Obergeschoss und verfügt über eine Wohnfläche von 113,3 m², die sich auf drei Zimmer, Flur, einem Abstellraum, zwei Bädern, Küche, einem Balkon und einer großzügigen Dachterrasse verteilen. 
Die Ausrichtung der Wohnung ist zu drei Gebäudeseiten. Vom Wohn-/ Esszimmer begeht man den große Terrasse und den Balkon mit den bodentiefen Fenstern. Hier bietet sich ein Blick in eine parkähnliche Umgebung.
", "wohnungD1.png", "wohnungD2.png", "wohnungD3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Othmarschen", 3759, 200, "Wunderschöne Erdgeschoßwohnung mit Garten in S-W Lage. Die Wohnung befindet sich in einer ruhigen Seitenstraße und verkehrsgünstiger Lage. Die S-Bahn Langenfelde sowie die Osterstraße befinden sich in unmittelbarer Nähe. 
Kinderfreundlich und tolles Nachbarschaftsverhältnis.", "wohnungE1.png", "wohnungE2.png", "wohnungE3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Rotherbaum", 2505, 80, "Im Herzen der Hansestadt Hamburg, nur wenige Gehminuten von der Innenstadt entfernt, liegt diese einzigartige Immobilie.

In der 4. Etage bietet das moderne City-Loft im aufstrebenden Stadtteil St. Georg mit seiner perfekten Seitenstraßenlage sowohl eine entspannte als auch eine urbane Umgebung.

Bereits im Eingangsbereich wird das Konzept der lockeren Aufteilung des isländischen Stararchitekten sichtbar. Individuelle Raumelemente und die moderne, offene Küche ergänzen den großzügigen, lichtdurchfluteten Wohnbereich.

Die Deckenhöhe von bis zu 2,90 Meter und das durchgehend verlegte Eichenparket unterstreichen das hochwertige Ambiente dieses Lofts.", "wohnungF1.png", "wohnungf2.png", "wohnungF3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Alsterdorf", 999, 75, "Diese von uns zu vermittelnde Maisonettewohnung mit einer großzügigen Wohn- und Nutzfläche von ca. 166 m² liegt in einer kleinen und exklusiven Wohnanlage unmittelbar am und gefühlt direkt im Niendorfer Gehege im begehrten Bezirk Eimsbüttel. Das beliebte Niendorfer-Gehege ist einst aus einigen kleinen Wäldern und vor allem aus mehreren großen Parkanlagen entstanden, welche mit den dazugehörigen Villen und Landsitzen von betuchten Hamburger Kaufleuten gegen Ende des 19. Jahrhunderts bebaut wurden. Als Anfang der 2000er Jahre Prominente, wie z.B. Til Schweiger und seine Familie, in die Villen einzogen, erhielt die exponierte Wohnlage einen überregionalen, medialen Bekanntheitsgrad. Eine dieser Villen und Landsitze wurde in den 80er Jahren saniert und in ein Mehrfamilienhaus umgebaut. Zur gleichen Zeit wurden auf dem selben über 6.000m² großen Park zwei weitere Mehrfamilienhäuser erbaut. In einem dieser hochwertig gebauten Wohnhäuser befindet sich auch diese großzügige Maisonettewohnung - mit mehr Wohnfläche als jedes standardisierte Einfamilienhaus. Zu der sonnigen Terrassenwohnung gehört zudem auch ein ca. 120 m² großer Gartenanteil (Sondernutzungsrecht) mit liebevoll angelegten Beeten für den Gartenfreund ohne Lust auf viel Arbeit - denn für die verbleibenden 6.108 m² Gartenfläche der Wohnanlage, welcher sogar einen Kinderspielplatz aufweist, kümmert sich ein Gärtner. ", "wohnungG1.png", "wohnungG2.png", "wohnungG3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Veddel", 666, 60, "Bei dem zu verkaufendem Objekt handelt es sich um eine gut aufgeteilte Maisonettewohnung im Reihenhauscharakter. Durch einen 
separaten Eingang erreichen Sie Ihre Maisonettewohnung, die sich im Obergeschoss und Dachgeschoss befindet. Insgesamt besteht das Haus aus zwei Vollgeschossen. 

Durch dem Eingang gelangen Sie direkt in den großzügigen Flurbereich. Von da aus gelangen Sie direkt in das ca. 45 qm große Wohnzimmer mit offener Küche, in der sich eine (im Preis enthaltene) Einbauküche befindet. Durch die bodentiefen Fenster dringt viel Licht in das Wohnzimmer und an kalten Tagen, lädt der eingebaute Kamin die gesamte Familie zum gemeinsamen und gemütlichen Tagesausklang ein. 

Ein zusätzliches Highlight der Wohnung ist die hauseigene Sauna, diese erreichen Sie über das Duschbad. 

Über den Flur gelangen Sie weiter in einen separaten, kleineren aber geräumigen Flur, der in das erste Kinderzimmer führt. Die untere Etage bietet mit seinen ca. 80 qm genug Platz für Ihren Alltag, wie das gemeinsame Kochen oder entspannen.

Über die Treppe gelangen Sie in das zweite Obergeschoss. Hier befindet sich das 22 m² große Schlafzimmer, wozu ein zusätzliches Ankleidezimmer gehört. In das zweite Bad inkl. Wanne gelangen Sie über 2 Eingänge, das Ankleidezimmer oder über den Flur. 
", "wohnungH1.png", "wohnungH2.png", "wohnungH3.png");
INSERT INTO objekte(ort, preis, grosse, beschreibung, bild1, bild2, bild3) VALUES ("Bahrenfeld", 1809, 112, "Diese traumhafte Wohnung im Marco Polo Tower gehört zu den größten Wohnungen im Haus. 
Sie wurde aus 2 Wohnungen zusammengelegt und besitzt somit auch 2 Eingänge.

Zum Tower:
Der Marco Polo Tower!
Der Marco Polo Tower zählt zu den exklusivsten Wohnhäusern in Deutschland und steht in dem renommierten Stadtteil, der Hafencity. Er zählt schon jetzt zu einem Wahrzeichen und besticht durch die einmalige Architektur.

Nun zu der Traumwohnung:
Die Wohnung befindet sich in der 11.Etage des Marco Polo Tower
und besitzt einen fast 270-Grad-Blick.
Des Weiteren besticht die Wohnung mit 2 Eingängen, sowie Kamine, Designbäder, EIB-System, Fußbodenheizung und den unverbaubaren Blick auf die Elbphilharmonie, sogar direkt vom Schlafzimmer! 
Ein Traumausblick beginnend an jedem Morgen, wenn die Vorhänge aufgehen.
Die Sonnenuntergänge sind atemberaubend! Siehe die Bilder anbei.", "wohnungI1.png", "wohnungI2.png", "wohnungI3.png");

SELECT * FROM objekte;

CREATE TABLE bewerbungen(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userID NUMERIC NOT NULL,
    objektID NUMERIC NOT NULL
);



SELECT * FROM bewerbungen;


